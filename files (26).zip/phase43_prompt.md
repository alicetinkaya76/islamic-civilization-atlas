# SEANS 4.3 — HANEDAN PEDAGOJİK ZENGİNLEŞTİRME (dynasty_id 1-93)

## BAĞLAM
İslam Medeniyeti Atlası projesi, Faza 4 (Pedagojik Zenginleştirme) kapsamında `all_dynasties_enriched.csv` dosyasına 8 yeni sütun ekliyoruz. Bu seans ilk 93 hanedanı kapsar.

Daha önce tamamlanan seanslar:
- 4.1.1: battles_v4.csv (50 savaş, +7 sütun) ✅
- 4.1.2: scholars_v4.csv (49 âlim, +7 sütun) + monuments_v4.csv (40 yapı, +7 sütun) ✅  
- 4.2: trade_routes_v4.csv (+5), diplomacy_v4.csv (+4), major_cities_v4.csv (+4) ✅

## YÜKLENECEK DOSYALAR
1. `dynasties_1_93.csv` — İlk 93 hanedan (44 mevcut sütun)
2. `plan_v5.md` — Güncel proje planı
3. `phase43_prompt.md` — Bu dosya

## EKLENECEK 8 YENİ SÜTUN

```
narrative_tr          — Bu hanedan neden önemli? Ne değiştirdi? (bağlamsal tarihsel anlatı)
narrative_en          — Aynısı İngilizce
key_contribution_tr   — En önemli mirası (tek cümle, özlü)
key_contribution_en   — Aynısı İngilizce
rise_reason_tr        — Neden/nasıl yükseldi? (1-2 cümle)
fall_reason_tr        — Neden/nasıl yıkıldı? (1-2 cümle)
context_before_tr     — Kuruluş öncesi ortam: "X hanedanı zayıflayınca..."
context_after_tr      — Yıkılış sonrası: "Toprakları Y ve Z arasında paylaşıldı..."
```

## TIER SİSTEMİ (importance_level'a göre derinlik)

| Tier | importance_level | narrative | Diğer alanlar |
|------|-----------------|-----------|---------------|
| A | Kritik (1 adet: #91 Selçuklular) | 4-5 cümle, detaylı stratejik analiz | Tüm 8 alan kapsamlı |
| B | Yüksek (11 adet) | 3-4 cümle, tarihsel bağlam | Tüm 8 alan dolu |
| C | Normal (73 adet) | 2-3 cümle, özlü bağlam | 6 alan (narrative + key_contribution + rise/fall + context_before/after) |
| D | Düşük (8 adet) | 1-2 cümle | 4 alan (narrative + key_contribution + rise/fall) |

### Yüksek/Kritik Hanedanlar (özel dikkat):
- **#1 Râşidûn** — İslam'ın ilk dört halife dönemi
- **#3 Abbâsîler** — İslam altın çağı
- **#75 Büveyhîler** — Şiî hanedanın Sünnî hilafeti kontrolü
- **#83 Sâmânîler** — Fars kültürel rönesansı
- **#89 Hârezmşahlar** — Moğol istilasının ilk hedefi
- **#91 Selçuklular** — Türk-İslam sentezinin kurucu gücü (KRİTİK)

## ÇALIŞMA YÖNTEMİ

### Format: TSV (tab-separated)
3 parçada üretilecek, ardından Python ile merge edilecek:
- Parça 1: dynasty_id 1-31
- Parça 2: dynasty_id 32-62  
- Parça 3: dynasty_id 63-93

### Her TSV'nin başlık satırı:
```
dynasty_id	narrative_tr	narrative_en	key_contribution_tr	key_contribution_en	rise_reason_tr	fall_reason_tr	context_before_tr	context_after_tr
```

### Merge Script Yapısı:
```python
# dynasties_1_93.csv + 3 TSV → dynasties_1_93_v4.csv
# Mevcut 44 sütun + 8 yeni sütun = 52 sütun
```

## NARRATİF KALİTESİ İLKELERİ

### ✅ YAPILACAKLAR
1. **Nedensellik zinciri:** "X hanedanı Y bölgesinde Z boşluktan yararlanarak kuruldu → A'yı başardı → B nedeniyle yıkıldı → C devraldı"
2. **Bağlamsal anlam:** Kuru kronoloji DEĞİL, "neden önemli?" sorusuna cevap
3. **Mevcut CSV verilerini kaynak olarak kullan:** `notes`, `end_cause`, `predecessor`, `successor`, `migration_conquest_notes` sütunlarındaki bilgileri narratife entegre et
4. **Cross-referans farkındalığı:** Hangi savaşlar, olaylar, âlimler bu hanedanla bağlantılı? (Doğrudan referans vermek zorunlu değil ama tutarlılık önemli)
5. **İki dilli:** narrative_tr ve narrative_en her zaman dolu

### ❌ YAPILMAYACAKLAR
1. Wikipedia kopyası DEĞİL — özgün pedagojik anlatı
2. Tekrar eden kalıplar DEĞİL — her hanedan için farklı açılış cümlesi
3. Belirsiz genellemeler DEĞİL — somut tarihsel referanslar
4. context_before/after boş bırakılmamalı (Düşük tier hariç)

## ÖRNEK ÇIKTI (Tier B — Yüksek)

**dynasty_id: 83 (Sâmânîler)**
```
narrative_tr: Sâmânîler, Abbâsî hakimiyeti altında Mâverâünnehir'de yükselen ve Fars kültürel rönesansının mimarı olan ilk büyük yerli İran hanedanıdır. İslam sonrası İran edebiyatının doğuşunu himaye ederek Firdevsî'nin Şehnâme geleneğinin temellerini attılar. Buhara'yı İslam dünyasının en parlak entelektüel merkezlerinden birine dönüştürdüler.

narrative_en: The Samanids were the first major native Iranian dynasty to rise under Abbasid suzerainty in Transoxiana, architecting the Persian cultural renaissance. They patronized the birth of post-Islamic Persian literature, laying foundations for Ferdowsi's Shahnameh tradition. They transformed Bukhara into one of the Islamic world's most brilliant intellectual centers.

key_contribution_tr: İslam sonrası Fars edebiyatı ve kültürel kimliğinin yeniden doğuşunu himaye ettiler.
key_contribution_en: They patronized the rebirth of post-Islamic Persian literature and cultural identity.

rise_reason_tr: Abbâsî valileri olarak Mâverâünnehir'de güç kazandılar; İranlı dihkan (toprak aristokrasisi) desteğiyle fiili bağımsızlık elde ettiler.
fall_reason_tr: Karahanlı Türklerinin kuzeyden ve Gaznelilerin güneyden eş zamanlı baskısıyla parçalanarak yıkıldılar.

context_before_tr: Abbâsî merkezi otoritesinin doğu eyaletlerinde zayıflamasıyla yerel İranlı hanedanlar (Tâhirîler, Saffârîler) bağımsızlık aradı.
context_after_tr: Mâverâünnehir Karahanlılara, Horasan Gaznelilere geçti; Sâmânî kültürel mirası her iki hanedan tarafından devam ettirildi.
```

## DOĞRULAMA

Merge sonrası kontrol:
- 93 satır × 52 sütun
- Empty narrative_tr: NONE
- Empty narrative_en: NONE
- Empty key_contribution_tr: NONE
- Tier D (Düşük) hanedanlarda context_before/after boş olabilir

Çıktı: `/mnt/user-data/outputs/dynasties_1_93_v4.csv`
